/**
 * @file testing without expressjs
 * @author Roi C.
 */
import { start } from './game';
console.log("Iniciando");
start(30);
console.log("Adios");