export class Bullet {
    constructor() {
        
    }
}